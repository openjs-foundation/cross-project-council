
# MOVE Token Claim via Remix

This project allows the Treasury Owner to claim 66M MOVE tokens using Remix.

## Steps

1. Open https://remix.ethereum.org
2. Upload `Movement.sol`
3. Compile the contract (Solidity 0.8.20)
4. Go to "Deploy & Run Transactions" tab
5. Use "Injected Web3" and connect your 0xb2cA... wallet
6. Under "At Address", input the Proxy Contract address: 0x3073f7aAA4DB83f95e9FFf17424F71D4751a3073
7. Click the `claim()` button
8. Confirm the MetaMask transaction

After confirmation, you should see the 66M MOVE token transferred to your wallet.

Verified on Base Mainnet.
